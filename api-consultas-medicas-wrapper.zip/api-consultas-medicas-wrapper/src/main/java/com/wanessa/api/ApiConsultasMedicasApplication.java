package com.wanessa.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiConsultasMedicasApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiConsultasMedicasApplication.class, args);
    }
}
